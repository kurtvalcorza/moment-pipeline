"""Review probes for tutorials/moment_classification_colab.ipynb (prefix MCL), row 55 of the 2026-10-02 relay.

CPU only (CUDA_VISIBLE_DEVICES=-1). Not a Colab run. Each subcommand merges its results into results.json.

  python run_probes.py static    --repo <worktree> --work <dir>
  python run_probes.py default   --repo <worktree> --work <dir>   # code cells 3..41 in one namespace
  python run_probes.py active    --repo <worktree> --work <dir>   # LEARNING_RATE = 3e-5 exercise after a default run
  python run_probes.py byod_norm --repo <worktree> --work <dir>   # BYOD positive/negative + normalisation invariance

`--work` must hold weights/moment-1-base/{README.md,config.json,model.safetensors} and weights/hapt/hapt.zip
(pre-staged copies; the notebook re-verifies both by SHA-256). The install cell runs with the notebook's own
DIMER_NOTEBOOK_CI_PREINSTALLED=1 hook against the repository's locked environment (uv sync --locked).
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import zipfile
from pathlib import Path

NB = "tutorials/moment_classification_colab.ipynb"
HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results.json"
HOSTED = Path(
    r"C:\Users\Kurt Valcorza\Projects\.agent\backups\kaggle-e2e-2026-09-19\out"
    r"\dimer-nb2-moment-classification\v1\evidence"
)


def merge(key, value):
    data = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def load_nb(repo):
    return json.loads((Path(repo) / NB).read_text(encoding="utf-8"))


def src(nb, i):
    return "".join(nb["cells"][i]["source"])


def run_cells(nb, indices, ns, replace=None, log=None):
    replace = replace or {}
    log = log if log is not None else []
    for i in indices:
        cell = nb["cells"][i]
        if cell["cell_type"] != "code":
            continue
        code = src(nb, i)
        for old, new in replace.get(i, []):
            assert old in code, (i, old)
            code = code.replace(old, new)
        buf = io.StringIO()
        t0 = time.perf_counter()
        entry = {"cell": i}
        try:
            with contextlib.redirect_stdout(buf):
                exec(compile(code, f"<cell {i}>", "exec"), ns)
            entry["ok"] = True
        except BaseException as exc:  # noqa: BLE001
            entry["ok"] = False
            entry["error"] = f"{type(exc).__name__}: {str(exc)[:400]}"
            entry["traceback_tail"] = traceback.format_exc()[-800:]
        entry["seconds"] = round(time.perf_counter() - t0, 1)
        entry["stdout_tail"] = buf.getvalue()[-2500:]
        log.append(entry)
        print(json.dumps({k: entry[k] for k in ("cell", "ok", "seconds")}), flush=True)
        if not entry["ok"]:
            return log, False
    return log, True


def fresh_ns():
    return {"__name__": "__main__"}


# ---------------------------------------------------------------- static
def static(repo, work):
    repo = Path(repo)
    nb = load_nb(repo)
    out = {}
    out["blob"] = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", f"HEAD:{NB}"], capture_output=True, text=True
    ).stdout.strip()
    out["nbformat"] = [nb["nbformat"], nb["nbformat_minor"]]
    out["n_cells"] = len(nb["cells"])
    code_idx = [i for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
    out["n_code_cells"] = len(code_idx)
    bad = []
    for i in code_idx:
        try:
            compile(src(nb, i), f"<cell {i}>", "exec")
        except SyntaxError as exc:
            bad.append([i, str(exc)])
    out["compile_failures"] = bad
    out["persisted_outputs"] = sum(1 for i in code_idx if nb["cells"][i].get("outputs"))
    out["metadata_dimer"] = {k: v for k, v in nb["metadata"]["dimer"].items() if k != "generated_from"}
    module_cells = [i for i in code_idx if nb["cells"][i]["metadata"].get("dimer", {}).get("embedded_module")]
    out["carried_module_cells"] = {
        "count": len(module_cells),
        "chars": sum(len(src(nb, i)) for i in module_cells),
        "any_cellView_form": any(nb["cells"][i]["metadata"].get("cellView") == "form" for i in module_cells),
        "any_infrastructure_title": any("Infrastructure" in src(nb, i)[:200] for i in module_cells),
    }
    md = {i: src(nb, i) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "markdown"}
    out["literal_double_braces_in_markdown"] = {
        i: re.findall(r".{0,30}\{\{[^}]*\}\}.{0,10}", s) for i, s in md.items() if "{{" in s
    }
    all_src = "\n".join(src(nb, i) for i in range(len(nb["cells"])))
    install = src(nb, 3)
    out["install_cell"] = {
        "pip_into_kernel": "'-m', 'pip', 'install'" in install,
        "uv_isolated_env": "uv venv" in install or "--managed-python" in install,
        "restart_guard": "Restart the runtime" in install,
        "pins": re.findall(r"'([^']+==[^']+|momentfm @ [^']+)'", install),
    }
    out["byod_cell"] = {
        "google_colab_upload": "files.upload()" in src(nb, 31),
        "location_field": bool(re.search(r"^BYOD_\w*PATH\s*=.*@param", src(nb, 31), re.M)),
        "reads_DIMER_BYOD_PATH": "DIMER_BYOD_PATH" in all_src,
    }
    guided = ["How to use", "Roadmap", "Glossary", "Troubleshooting", "Check your reasoning", "Predict", "Infrastructure"]
    out["guided_layer_markers_present"] = {g: (g.lower() in all_src.lower()) for g in guided}
    out["spec_declared_in_opening"] = re.findall(r"Notebook Specification (\d\.\d)", md[0])
    # numbers the prose asserts versus the recorded hosted run of the same blob
    prose = "\n".join(md.values())
    out["prose_claims"] = {
        "77.8 % (selected, build record)": prose.count("77.8"),
        "two windows better": ("two windows" in prose),
        "laying and sitting recall rising from 0.33 to 0.50": ("laying and sitting recall rising from 0.33 to 0.50" in prose),
        "partly recover": prose.count("partly recover"),
        "head cannot recover": ("a head cannot recover information the normalisation removed" in prose),
        "CPU time opening": re.findall(r"about (\w+ minutes) of model time", prose),
        "CPU time prereq unfreeze": re.findall(r"took about (\d+ s)", prose),
        "section 7 CPU estimate": re.findall(r"about (three minutes) on CPU", prose),
    }
    hosted = {}
    ex = HOSTED / "executed.ipynb"
    if ex.exists():
        hnb = json.loads(ex.read_text(encoding="utf-8"))
        def text(c):
            t = ""
            for o in c.get("outputs", []):
                if o.get("output_type") == "stream":
                    t += "".join(o["text"])
                elif o.get("output_type") == "error":
                    t += "ERROR " + o["ename"] + ": " + o["evalue"]
            return t
        hosted["cell29_device_print"] = re.findall(r"\{'device'.*\}", text(hnb["cells"][29]))
        hosted["cell33_cosines"] = re.findall(r"\{'cosine_same_activity'.*\}", text(hnb["cells"][33]))
        hosted["cell39"] = text(hnb["cells"][39])[:1500]
        hosted["cell41_predictions"] = re.findall(r"\{'id': 'test-00\d'.*\}", text(hnb["cells"][41]))
        p1 = json.loads((HOSTED / "executed-pass1.ipynb").read_text(encoding="utf-8"))
        hosted["pass1_errors"] = [
            [i, o["ename"], o["evalue"][:300]]
            for i, c in enumerate(p1["cells"]) for o in c.get("outputs", []) if o.get("output_type") == "error"
        ]
        hosted["executed_sha256"] = hashlib.sha256(ex.read_bytes()).hexdigest()
    out["hosted_record_2026_09_19"] = hosted
    py = sys.executable
    for name, cmd in {
        "build_check": [py, "tools/build_notebook.py", "--template", "tools/notebook_template_classification.py",
                        "--out", NB, "--check"],
        "validate_release_assets": [py, "tools/validate_release_assets.py"],
    }.items():
        r = subprocess.run(cmd, cwd=repo, capture_output=True, text=True, timeout=300)
        out[name] = {"exit": r.returncode, "tail": (r.stdout + r.stderr)[-600:]}
    merge("P1_static", out)
    print(json.dumps(out, indent=1, default=str)[:6000])


# ---------------------------------------------------------------- default
def default(repo, work):
    nb = load_nb(repo)
    os.chdir(work)
    ns = fresh_ns()
    t0 = time.perf_counter()
    log, ok = run_cells(nb, range(3, 42), ns)
    out = {"cells": log, "all_ok": ok, "wall_seconds": round(time.perf_counter() - t0, 1)}
    if ok:
        import torch
        from safetensors.torch import save_file

        a = ns["adapter"]
        out["selected_policy"] = a.policy
        out["best_epoch"] = a.config["best_epoch"]
        out["history_val_log_loss"] = [h["val"]["log_loss"] for h in a.history]
        out["comparison"] = ns["comparison"]
        out["reload_parity"] = ns["parity"]
        out["predictions"] = ns["rows"]
        out["device"] = ns["pipe"].identity.device
        out["torch_threads"] = torch.get_num_threads()
        params = dict(ns["pipe"].pipeline.named_parameters())
        fresh = dict(ns["frozen_pipe"].pipeline.named_parameters())
        moved = [n for n in params if not torch.equal(params[n], fresh[n])]
        out["pipe_params_differing_from_fresh_base"] = {"count": len(moved), "first": moved[:3]}
        if a.trainable_names:
            save_file({n: params[n].detach().contiguous() for n in a.trainable_names},
                      str(Path(work) / "adapted_blocks.safetensors"))
            out["saved_adapted_blocks"] = len(a.trainable_names)
    merge("P2_default_cpu", out)
    print(json.dumps({k: v for k, v in out.items() if k != "cells"}, indent=1, default=str))


# ---------------------------------------------------------------- active
def active(repo, work):
    """Learner exercise 'set LEARNING_RATE = 3e-5' done as a learner would after the default run: edit
    Section 7 and rerun Sections 7-9 in the same kernel. The kernel state after the default run is
    reproduced by running Sections 1-6 fresh and overlaying the two blocks the default run trained (P2)."""
    import_ok = (Path(work) / "adapted_blocks.safetensors").exists()
    if not import_ok:
        merge("P3_active_lr3e-5", {"skipped": "P2 did not save adapted blocks"})
        return
    nb = load_nb(repo)
    os.chdir(work)
    ns = fresh_ns()
    log, ok = run_cells(nb, range(3, 36), ns)
    out = {"setup_cells_ok": ok}
    if not ok:
        out["setup_log"] = log
        merge("P3_active_lr3e-5", out)
        return
    import torch
    from safetensors.torch import load_file

    saved = load_file(str(Path(work) / "adapted_blocks.safetensors"))
    params = dict(ns["pipe"].pipeline.named_parameters())
    with torch.no_grad():
        for n, v in saved.items():
            params[n].copy_(v)
    out["overlaid_tensors"] = len(saved)
    out["section6_frozen_test_pristine"] = {k: ns["frozen_test"][k] for k in ("accuracy", "macro_f1", "log_loss")}
    out["section6_probe_val_log_loss_pristine"] = ns["probe_adapter"].history[0]["val"]["log_loss"]
    log2, ok2 = run_cells(
        nb, [37, 39, 41], ns, replace={37: [("LEARNING_RATE = 3e-4", "LEARNING_RATE = 3e-5")]}
    )
    out["rerun_cells"] = log2
    a = ns.get("adapter")
    if a is not None:
        out["rerun_selected_policy"] = a.policy
        out["rerun_best_epoch"] = a.config["best_epoch"]
        out["rerun_epoch0_val_log_loss"] = a.history[0]["val"]["log_loss"]
        out["rerun_history_val_log_loss"] = [h["val"]["log_loss"] for h in a.history]
        out["rerun_trainable_names_saved"] = len(a.trainable_names)
    if "parity" in ns:
        out["rerun_parity"] = ns["parity"]
    out["all_rerun_cells_ok"] = ok2
    merge("P3_active_lr3e-5", out)
    print(json.dumps({k: v for k, v in out.items() if k != "rerun_cells"}, indent=1, default=str))
    for e in log2:
        print(e["cell"], e["ok"], e.get("error"), e["stdout_tail"][-900:])


# ---------------------------------------------------------------- stale encoder state (mechanism, small inputs)
def stale(repo, work):
    """Mechanism probe for the rerun instructions (optional experiments; BYOD 're-run from Section 4').
    Small stand-in inputs (24 train / 12 validation / 6 test HAPT windows) so it fits the time cap:
    1) an unfreeze run whose winner modifies `pipe` in place (as Section 7 does on the default path);
    2) a second `adapt` on the same `pipe` that selects the frozen policy (as a rerun of Section 6, a
       LEARNING_RATE = 3e-5 rerun of Section 7, or a BYOD rerun from Section 4 can), then the Section 9
       export -> fresh `load_moment` -> `load_artifact` -> `classify` parity check."""
    nb = load_nb(repo)
    os.chdir(work)
    ns = fresh_ns()
    log, ok = run_cells(nb, list(range(3, 30)) + [31], ns)
    out = {"setup_ok": ok, "inputs": "stand-in subset: 24 train / 12 validation / 6 test windows of the default HAPT split"}
    if not ok:
        out["setup_log"] = log
        merge("P3_stale_state", out)
        return
    import torch

    g = ns
    pipe = g["pipe"]
    tr, va, te = g["train_records"][:24], g["val_records"][:12], g["test_records"][:6]
    base = {n: p.detach().clone() for n, p in pipe.pipeline.named_parameters()}
    t0 = time.perf_counter()
    first = g["adapt"](pipe, tr, va, trainable_blocks=1, epochs=2, lr=1e-3, batch_size=8)
    out["run1"] = {"policy": first.policy, "best_epoch": first.config["best_epoch"],
                   "val_log_loss": [h["val"]["log_loss"] for h in first.history],
                   "seconds": round(time.perf_counter() - t0, 1)}
    moved = [n for n, p in pipe.pipeline.named_parameters() if not torch.equal(p, base[n])]
    out["params_moved_in_pipe_after_run1"] = len(moved)
    t0 = time.perf_counter()
    second = g["adapt"](pipe, tr, va, trainable_blocks=0)
    out["run2_frozen_policy"] = {"policy": second.policy, "trainable_names": len(second.trainable_names),
                                 "seconds": round(time.perf_counter() - t0, 1)}
    fresh = g["load_moment"](task="embedding", weights_dir=g["WEIGHTS_DIR"])
    f_pipe, _ = g["features"](te, pipe)
    f_fresh, _ = g["features"](te, fresh)
    import numpy as np
    out["embedding_max_abs_diff_pipe_vs_fresh_base"] = float(np.abs(np.asarray(f_pipe) - np.asarray(f_fresh)).max())
    adir = Path(work) / "stale_artifact"
    import shutil
    shutil.rmtree(adir, ignore_errors=True)
    g["save_artifact"](pipe, second, adir)
    manifest = json.loads((adir / "manifest.json").read_text(encoding="utf-8"))
    out["artifact_tensors"] = manifest["tensors"]
    in_mem = g["classify"](pipe, second, te)
    reloaded = g["load_artifact"](fresh, adir)
    after = g["classify"](fresh, reloaded, te)
    p1, p2 = np.asarray(in_mem["probabilities"]), np.asarray(after["probabilities"])
    out["parity"] = {
        "probabilities_identical": in_mem["probabilities"] == after["probabilities"],
        "max_abs_prob_diff": float(np.abs(p1 - p2).max()),
        "labels_in_memory": in_mem["labels"], "labels_reloaded": after["labels"],
        "section9_assert_would_pass": in_mem["probabilities"] == after["probabilities"],
    }
    merge("P3_stale_state", out)
    print(json.dumps(out, indent=1, default=str))


# ---------------------------------------------------------------- byod + normalisation
def byod_norm(repo, work):
    nb = load_nb(repo)
    os.chdir(work)
    ns = fresh_ns()
    log, ok = run_cells(nb, list(range(3, 30)), ns)
    out = {"setup_ok": ok}
    if not ok:
        out["setup_log"] = log
        merge("P4_byod_norm", out)
        return
    import numpy as np

    g = ns
    corpus = g["read_corpus"](g["fetch_corpus"](cache_dir="weights/hapt"))
    pipe = g["pipe"]
    # P4a: per-window instance normalisation -> offset/scale invariance of the pooled embedding
    rec = next(r for r in corpus if r["label"] == "sitting")
    offset = np.array([[1.0], [-2.0], [0.5], [0.3], [-0.2], [0.1]], dtype=np.float32)
    variants = [
        {"id": "orig", "x": rec["x"], "label": "a"},
        {"id": "offset", "x": (rec["x"] + offset).astype(np.float32), "label": "b"},
        {"id": "scaled", "x": (rec["x"] * 3.0).astype(np.float32), "label": "a"},
    ]
    vecs, _ = g["features"](variants, pipe)
    vecs = np.asarray(vecs)
    out["norm_invariance"] = {
        "max_abs_diff_offset": float(np.abs(vecs[0] - vecs[1]).max()),
        "max_abs_diff_scale": float(np.abs(vecs[0] - vecs[2]).max()),
        "cosine_offset": float(vecs[0] @ vecs[1] / np.linalg.norm(vecs[0]) / np.linalg.norm(vecs[1])),
    }
    means = {}
    for lab in ("sitting", "standing", "laying"):
        xs = np.stack([r["x"][:3].mean(axis=1) for r in corpus if r["label"] == lab])
        means[lab] = [round(float(v), 3) for v in xs.mean(axis=0)]
    out["static_posture_mean_acc_xyz"] = means
    # P4b: BYOD positive - zip of HAPT windows from 12 volunteers, records.csv with group
    users = sorted({r["user"] for r in corpus})[:12]
    chosen = [r for r in corpus if r["user"] in users]
    zpath = Path(work) / "byod_ok.zip"
    with zipfile.ZipFile(zpath, "w") as z:
        lines = ["id,file,label,group"]
        for k, r in enumerate(chosen):
            b = io.BytesIO()
            np.save(b, r["x"])
            z.writestr(f"w{k:03d}.npy", b.getvalue())
            lines.append(f"u{r['user']}-{k:03d},w{k:03d}.npy,{r['label']},vol{r['user']}")
        z.writestr("records.csv", "\n".join(lines) + "\n")
    res = {}
    try:
        recs = g["load_byod_dataset"](zpath)
        splits = g["split_dataset"](recs, seed=42)
        res["n"] = len(recs)
        res["splits"] = {k: len(v) for k, v in splits.items()}
        res["disjoint"] = g["check_split_disjoint"](splits)
        for k, v in splits.items():
            g["validate_dataset"](v)
        res["test_classes"] = sorted({r["label"] for r in splits["test"]})
        res["train_classes"] = sorted({r["label"] for r in splits["train"]})
        probe = g["adapt"](pipe, splits["train"], splits["validation"], trainable_blocks=0)
        ev = g["evaluate"](pipe, probe, splits["test"])
        res["probe_test"] = {k: ev[k] for k in ("accuracy", "macro_f1", "n", "verdict")}
        res["reached"] = "validate -> split -> frozen-policy adapt -> evaluate (unfreeze not run: cost)"
    except Exception as exc:  # noqa: BLE001
        res["error"] = f"{type(exc).__name__}: {exc}"
    out["byod_positive"] = res
    # P4c: BYOD negatives
    neg = {}
    def attempt(name, fn):
        try:
            fn()
            neg[name] = "accepted"
        except Exception as exc:  # noqa: BLE001
            neg[name] = f"{type(exc).__name__}: {str(exc)[:220]}"
    nog = Path(work) / "byod_nogroup.zip"
    with zipfile.ZipFile(nog, "w") as z:
        b = io.BytesIO(); np.save(b, chosen[0]["x"]); z.writestr("a.npy", b.getvalue())
        z.writestr("records.csv", "id,file,label\nx1,a.npy,sitting\n")
    attempt("records.csv without group", lambda: g["load_byod_dataset"](nog))
    short = [{"id": f"s{k}", "x": r["x"][:, :500], "label": r["label"], "group": "g"} for k, r in enumerate(chosen[:8])]
    attempt("windows of length 500", lambda: g["validate_dataset"](short))
    attempt("a .csv instead of a .zip", lambda: g["load_byod_dataset"](Path(work) / "x.csv"))
    attempt("USE_BYOD=True outside Colab (import google.colab)", lambda: __import__("google.colab"))
    out["byod_negative"] = neg
    merge("P4_byod_norm", out)
    print(json.dumps(out, indent=1, default=str))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("probe", choices=["static", "default", "active", "stale", "byod_norm"])
    ap.add_argument("--repo", required=True)
    ap.add_argument("--work", required=True)
    a = ap.parse_args()
    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
    assert os.environ.get("CUDA_VISIBLE_DEVICES") == "-1", "set CUDA_VISIBLE_DEVICES=-1"
    {"static": static, "default": default, "active": active, "stale": stale, "byod_norm": byod_norm}[a.probe](a.repo, a.work)
