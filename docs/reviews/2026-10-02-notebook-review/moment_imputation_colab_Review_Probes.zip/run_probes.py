"""Review probes for tutorials/moment_imputation_colab.ipynb (row 57, prefix MIM).

Direct execution, local Windows CPU only (CUDA_VISIBLE_DEVICES=-1, 4 torch threads), venv dimer-moment whose
versions equal the notebook PINS. NOT a Colab run. The install cell runs with the notebook's own
DIMER_NOTEBOOK_CI_PREINSTALLED=1 (nothing installed). The 3-file snapshot is pre-staged by copying the pinned
files into the scratch working directory (stage_missing_files then fetches nothing); HF_HUB_OFFLINE=1.
Scale: the default sample is the full default (1 series, 2 channels, 256 steps); placement and BYOD probes use
the same sample or small synthetic CSVs (reduced scale, labelled as such).

Usage: python run_probes.py <repo_worktree> <workdir> <prestaged_weights_dir> [<hosted_outputs_dir>]
Writes <workdir>/results.json (written after every probe).
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
import types
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
PRESTAGED = Path(sys.argv[3]).resolve()
HOSTED = Path(sys.argv[4]).resolve() if len(sys.argv) > 4 else None
NBREL = "tutorials/moment_imputation_colab.ipynb"
NB = REPO / NBREL
RESULTS: dict = {"environment": {}, "probes": {}}
WORK.mkdir(parents=True, exist_ok=True)


def record(name, value):
    RESULTS["probes"][name] = value
    (WORK / "results.json").write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


def git(*args):
    return subprocess.run(["git", "-C", str(REPO), *args], capture_output=True, text=True).stdout.strip()


# ---------------- P1 static ----------------
nb = json.loads(NB.read_text(encoding="utf-8"))
code_cells = [i for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
compile_errors = []
for i in code_cells:
    try:
        compile("".join(nb["cells"][i]["source"]), f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append((i, str(exc)))
persisted = [i for i in code_cells if nb["cells"][i].get("outputs") or nb["cells"][i].get("execution_count")]
p1 = {
    "nbformat": f"{nb['nbformat']}.{nb['nbformat_minor']}",
    "cells": len(nb["cells"]),
    "code_cells": len(code_cells),
    "compile_errors": compile_errors,
    "persisted_outputs": persisted,
    "head": git("rev-parse", "HEAD"),
    "blob": git("rev-parse", f"HEAD:{NBREL}"),
    "recorded_run_blob": "505e74302b0d7ab7b528130281e06e56cdf74683",
    "metadata_dimer_spec": nb["metadata"].get("dimer", {}).get("notebook_spec"),
    "carried_module_chars": sum(len("".join(nb["cells"][i]["source"])) for i in range(5, 24, 2)),
}
p1["blob_equals_recorded_run"] = p1["blob"] == p1["recorded_run_blob"]
for label, cmd in (
    ("build_check", [sys.executable, "tools/build_notebook.py", "--check"]),
    ("validate_release_assets", [sys.executable, "tools/validate_release_assets.py"]),
):
    proc = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, timeout=300)
    p1[label] = {"exit": proc.returncode, "tail": (proc.stdout + proc.stderr)[-500:]}
record("P1_static", p1)

# ---------------- execution harness ----------------
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ.pop("DIMER_BYOD_PATH", None)
os.chdir(WORK)
wdir = WORK / "weights" / "moment-1-base"
wdir.mkdir(parents=True, exist_ok=True)
for name in ("README.md", "config.json", "model.safetensors"):
    if not (wdir / name).exists():
        shutil.copy2(PRESTAGED / name, wdir / name)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402

torch.set_num_threads(4)
RESULTS["environment"] = {
    "python": sys.version.split()[0],
    "torch": torch.__version__,
    "numpy": np.__version__,
    "pandas": pd.__version__,
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "cuda_available": torch.cuda.is_available(),
    "threads": torch.get_num_threads(),
    "note": "local Windows CPU; not Colab; install skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1; snapshot pre-staged; HF_HUB_OFFLINE=1",
}

NS: dict = {"__name__": "__main__"}


def src(i):
    return "".join(nb["cells"][i]["source"])


def run_cell(i, source=None, ns=NS):
    buf = io.StringIO()
    t0 = time.time()
    status, err = "ok", None
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(source if source is not None else src(i), f"cell{i}", "exec"), ns)
        except BaseException as exc:  # noqa: BLE001
            status, err = "error", f"{type(exc).__name__}: {exc}"[:1500]
    return {"cell": i, "status": status, "error": err, "seconds": round(time.time() - t0, 2), "stdout": buf.getvalue()[-2500:]}


# ---------------- P2 default Run all ----------------
p2 = {"cells": []}
t0 = time.time()
for i in code_cells:
    r = run_cell(i)
    p2["cells"].append({k: r[k] for k in ("cell", "status", "error", "seconds")})
    if r["status"] != "ok":
        p2["failed_stdout"] = r["stdout"]
        break
    if i == 25:
        p2["section3_stdout_tail"] = r["stdout"][-400:]
p2["wall_s"] = round(time.time() - t0, 1)
p2["ok"] = sum(c["status"] == "ok" for c in p2["cells"])
p2["outputs"] = sorted(os.listdir("outputs")) if Path("outputs").exists() else []
if NS.get("metrics") is not None:
    W = NS["windows"]
    start, stop = NS["start"], NS["stop"]
    p2["held_out_positions"] = [start, stop - 1]
    p2["valid_positions"] = int(W.input_mask[0].sum())
    p2["holdout_is_final_patch_of_series"] = bool(stop == W.sequence_length)
    p2["mae"] = NS["metrics"].mae
    p2["rmse"] = NS["metrics"].rmse
    p2["baseline"] = NS["baseline_metrics"]
    p2["mae_ratio_model_over_baseline"] = NS["metrics"].mae / NS["baseline_metrics"]["mae"]
    bf = NS["baseline_frame"]
    norm = NS["normalized"]
    # Is the "linear interpolation" baseline actually a flat hold of the last observed value (no right neighbour)?
    flat = {}
    for ch in W.channels:
        s = norm[(norm.channel == ch)].sort_values("timestamp")
        held = bf[bf.channel == ch]
        last_before = float(s[~s.timestamp.isin(held.timestamp)]["value"].iloc[-1])
        flat[ch] = {
            "baseline_predictions_unique": sorted({round(x, 6) for x in held["prediction"]}),
            "last_observed_before_holdout": round(last_before, 6),
            "observed_after_holdout": int((s.timestamp > held.timestamp.max()).sum()),
        }
    p2["baseline_shape"] = flat
    imp = NS["imputed_frame"]
    hid = imp[imp.requested_hidden]
    per_ch = {}
    for ch in W.channels:
        h = hid[hid.channel == ch]
        b = bf[bf.channel == ch]
        per_ch[ch] = {
            "model_mae": float((h.imputed_value - h.original_value).abs().mean()),
            "baseline_mae": float((b.prediction - b.truth).abs().mean()),
            "series_std": float(norm[norm.channel == ch]["value"].std()),
            "series_mean": float(norm[norm.channel == ch]["value"].mean()),
        }
    p2["per_channel"] = per_ch
    obs = imp[(~imp.requested_hidden) & imp.source_observed]
    p2["observed_values_preserved"] = bool(np.allclose(obs.imputed_value, obs.original_value))
    p2["reconstruction_mae_on_visible_points_per_channel"] = {
        ch: float((obs[obs.channel == ch].reconstruction - obs[obs.channel == ch].original_value).abs().mean()) for ch in W.channels
    }
    p2["svg_channel"] = str(W.channels[0])
    if HOSTED is not None and (HOSTED / "moment_imputation_metrics.json").exists():
        hm = json.loads((HOSTED / "moment_imputation_metrics.json").read_text(encoding="utf-8"))
        p2["hosted_mae"] = hm["mae"]
        p2["hosted_baseline"] = hm["linear_interpolation_baseline"]
        p2["abs_diff_mae_vs_hosted"] = abs(hm["mae"] - NS["metrics"].mae)
        hs = pd.read_csv(HOSTED / "moment_imputed_series.csv")
        p2["max_abs_diff_imputed_vs_hosted"] = float(np.abs(hs.imputed_value.to_numpy() - imp.imputed_value.to_numpy()).max())
record("P2_default", p2)

# ---------------- P3 holdout placement: interior patches vs the trailing patch ----------------
p3 = {}
if NS.get("metrics") is not None:
    W = NS["windows"]
    pipe = NS["pipe"]
    impute = NS["impute"]
    mpm = NS["masked_point_metrics"]
    norm = NS["normalized"]
    first_valid = int(np.argmax(W.input_mask[0] == 1))
    rows = []
    for s0 in range(first_valid, W.sequence_length, W.patch_length):
        vis = np.ones_like(W.input_mask, dtype=np.float32)
        vis[0, s0:s0 + W.patch_length] = 0.0
        res = impute(W, pipe, mask=vis, warmup=False)
        m = mpm(res)
        held = set(pd.Series(W.timestamps[0][s0:s0 + W.patch_length]).tolist())
        errs = []
        for ch in W.channels:
            s = norm[norm.channel == ch].sort_values("timestamp").copy()
            hmask = s.timestamp.isin(held)
            pred = s["value"].mask(hmask).interpolate(method="linear", limit_direction="both")
            errs.extend((pred[hmask] - s.loc[hmask, "value"]).abs().tolist())
        rows.append({"start": s0, "model_mae": round(m.mae, 4), "baseline_mae": round(float(np.mean(errs)), 4)})
    interior = [r for r in rows if r["start"] not in (first_valid, W.sequence_length - W.patch_length)]
    p3 = {
        "n_patches": len(rows),
        "rows": rows,
        "interior_model_mae_median": float(np.median([r["model_mae"] for r in interior])),
        "interior_baseline_mae_median": float(np.median([r["baseline_mae"] for r in interior])),
        "interior_patches_model_better": sum(r["model_mae"] < r["baseline_mae"] for r in interior),
        "n_interior": len(interior),
        "trailing_patch": rows[-1],
    }
    # No artificial mask at all: report is not-measurable; observed values all preserved
    res0 = impute(W, pipe, mask=None, warmup=False)
    rep0 = NS["evaluation_report"](res0, model=pipe, sample_kind="synthetic")
    p3["no_mask_verdict"] = rep0["verdict"]
    # Full-length (512-step, no left padding) version of the same formulas
    n = 512
    ts = pd.date_range("2026-01-01", periods=n, freq="15min")
    step = np.arange(n, dtype=float)
    rows512 = []
    for channel, base, amplitude, period, phase, trend in (("vibration", 1.5, 0.35, 32.0, 0.0, 0.0008), ("temperature", 28.0, 2.5, 96.0, 9.0, 0.0015)):
        v = base + trend * step + amplitude * np.sin(2.0 * np.pi * (step + phase) / period) + 0.08 * np.cos(2.0 * np.pi * step / 16.0)
        rows512 += [("A", t, channel, float(x)) for t, x in zip(ts, v)]
    f512 = pd.DataFrame(rows512, columns=["series_id", "timestamp", "channel", "value"])
    cfg = NS["MomentConfig"](task="reconstruction")
    rep, nrm = NS["validate_long_frame"](f512, cfg)
    W5 = NS["to_windows"](nrm, cfg, report=rep, frame=nrm)
    out512 = []
    for s0 in (256, 384, 504):
        vis = np.ones_like(W5.input_mask, dtype=np.float32)
        vis[0, s0:s0 + 8] = 0.0
        out512.append({"start": s0, "model_mae": round(mpm(impute(W5, pipe, mask=vis, warmup=False)).mae, 4)})
    p3["full_length_512_no_padding"] = out512
record("P3_holdout_placement", p3)

# ---------------- P4 active learning / BYOD (the notebook's suggested next experiment) ----------------
p4 = {}


def write_csv(name, frame=None, text=None, encoding="utf-8"):
    path = WORK / "byod" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if text is not None:
        path.write_bytes(text.encode(encoding))
    else:
        frame.to_csv(path, index=False, date_format="%Y-%m-%dT%H:%M:%S")
    return path


rng = np.random.default_rng(0)
rows = []
tA = pd.date_range("2026-03-01", periods=300, freq="h")
tB = pd.date_range("2026-03-01", periods=120, freq="h")
for sid, ts in (("A", tA), ("B", tB)):
    for ch, base in (("flow", 10.0), ("pressure", 3.0)):
        v = base + np.sin(np.arange(len(ts)) / 12.0) + rng.normal(0, 0.1, len(ts))
        rows += [(sid, t, ch, float(x)) for t, x in zip(ts, v)]
byod = pd.DataFrame(rows, columns=["series_id", "timestamp", "channel", "value"])
# genuine source gaps in A: 5 NaN points in 'flow' only (rows kept), and the last 3 'flow' points NaN
a_flow = byod.index[(byod.series_id == "A") & (byod.channel == "flow")]
byod.loc[a_flow[100:105], "value"] = np.nan
byod.loc[a_flow[-3:], "value"] = np.nan
good = write_csv("gappy_two_series.csv", byod)
os.environ["DIMER_BYOD_PATH"] = str(good)
cells_after = [i for i in code_cells if i >= 27]
byod_run = [run_cell(i) for i in cells_after]
entry = {"cells": [(r["cell"], r["status"], r["error"]) for r in byod_run]}
if all(r["status"] == "ok" for r in byod_run):
    W = NS["windows"]
    imp = NS["imputed_frame"]
    entry.update({
        "window_ids": list(W.window_ids),
        "channels": list(W.channels),
        "held_out_positions": [NS["start"], NS["stop"] - 1],
        "holdout_moved_off_final_patch": NS["stop"] != W.sequence_length,
        "source_masked_point_fraction": NS["result"].masked_point_fraction,
        "model_masked_point_fraction": NS["result"].model_masked_point_fraction,
        "masked_patch_fraction": NS["result"].masked_patch_fraction,
        "source_missing_rows_filled": int(imp.source_missing.sum()),
        "pressure_points_hidden_because_flow_missing": int(((imp.channel == "pressure") & imp.model_hidden & imp.source_observed & ~imp.requested_hidden).sum()),
        "observed_preserved": bool(np.allclose(imp[imp.source_observed & ~imp.requested_hidden].imputed_value, imp[imp.source_observed & ~imp.requested_hidden].original_value)),
        "mae": NS["metrics"].mae,
        "baseline": NS["baseline_metrics"],
        "scored_windows": sorted(set(imp[imp.requested_hidden].window_id)),
        "report_verdict": NS["report"]["verdict"],
        "sample_in_result": json.loads(Path("outputs/moment_imputation_result.json").read_text(encoding="utf-8"))["sample"]["kind"],
        "svg_series_mix": sorted(set(imp[imp.channel == W.channels[0]].tail(96).series_id)),
    })
p4["gappy_byod"] = entry
record("P4_active_byod", p4)

invalid = {
    "duplicate_header": "series_id,timestamp,channel,value,value\nA,2026-01-01T00:00:00,x,1.0,2.0\n",
    "non_numeric_value": "series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,x,abc\nA,2026-01-01T01:00:00,x,2.0\n",
    "duplicate_key": "series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,x,1.0\nA,2026-01-01T00:00:00,x,2.0\n",
    "too_short_6_steps": "series_id,timestamp,channel,value\n" + "".join(f"A,2026-01-01T0{h}:00:00,x,{h}.0\n" for h in range(6)),
}
p4["invalid"] = {}
for name, text in invalid.items():
    path = write_csv(name + ".csv", text=text)
    os.environ["DIMER_BYOD_PATH"] = str(path)
    r27 = run_cell(27)
    e = {"cell27": r27["status"], "error27": r27["error"]}
    if r27["status"] == "ok":
        r29 = run_cell(29)
        e.update({"cell29": r29["status"], "error29": r29["error"]})
    p4["invalid"][name] = e
record("P4_active_byod", p4)

os.environ.pop("DIMER_BYOD_PATH", None)
r = run_cell(27, src(27).replace("USE_BYOD = False", "USE_BYOD = True"))
p4["use_byod_true_without_colab"] = {"status": r["status"], "error": r["error"]}
shim = types.ModuleType("google.colab")
shim.files = types.SimpleNamespace(upload=lambda: {})
sys.modules["google"] = types.ModuleType("google")
sys.modules["google.colab"] = shim
r = run_cell(27, src(27).replace("USE_BYOD = False", "USE_BYOD = True"))
p4["upload_cancelled_shim"] = {"status": r["status"], "error": r["error"]}
record("P4_active_byod", p4)
# ---------------- P5 reconstruction fidelity on the hosted run's exported series (documented execution) ----------------
if HOSTED is not None and (HOSTED / "moment_imputed_series.csv").exists():
    hs = pd.read_csv(HOSTED / "moment_imputed_series.csv")
    p5 = {}
    for ch, g in hs.groupby("channel"):
        vis = g[g.source_observed & ~g.model_hidden]
        p5[ch] = {
            "visible_points": int(len(vis)),
            "recon_mae_visible": float((vis.reconstruction - vis.original_value).abs().mean()),
            "predict_series_mean_mae": float((vis.original_value - vis.original_value.mean()).abs().mean()),
            "pearson_recon_vs_original_visible": float(np.corrcoef(vis.reconstruction, vis.original_value)[0, 1]),
        }
    record("P5_hosted_reconstruction_fidelity", p5)
# ---------------- P6 upstream reconstruct() called directly on clean, fully visible sinusoids ----------------
# Same loaded instance (pipe.pipeline is the upstream momentfm MOMENTPipeline). No masking at all: if the
# reconstruction does not track an input it fully sees, the imputation lesson cannot work either.
if NS.get("pipe") is not None:
    import transformers  # noqa: E402
    p6 = {"transformers": transformers.__version__, "head_type": type(NS["pipe"].pipeline.head).__name__,
          "proof_keys": sorted(NS["pipe"].proof.keys()) if isinstance(NS["pipe"].proof, dict) else None}
    t = np.arange(512, dtype=np.float32)
    cases = {"sine_period_32": np.sin(2 * np.pi * t / 32), "sine_period_96_plus_trend": 28 + 2.5 * np.sin(2 * np.pi * t / 96) + 0.0015 * t}
    for name, x in cases.items():
        x_enc = torch.from_numpy(x.astype(np.float32))[None, None, :]
        ones = torch.ones(1, 512)
        with torch.no_grad():
            for label, kwargs in (("mask_all_visible", {"mask": ones}), ("mask_omitted", {})):
                out = NS["pipe"].pipeline.reconstruct(x_enc=x_enc, input_mask=ones, **kwargs).reconstruction.numpy().ravel()
                p6[f"{name}/{label}"] = {
                    "pearson": float(np.corrcoef(out, x)[0, 1]),
                    "mae": float(np.abs(out - x).mean()),
                    "predict_mean_mae": float(np.abs(x - x.mean()).mean()),
                }
    record("P6_upstream_reconstruct_fully_visible", p6)
print("done", RESULTS["probes"]["P2_default"].get("wall_s"))
