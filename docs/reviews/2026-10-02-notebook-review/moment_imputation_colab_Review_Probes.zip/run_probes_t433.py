"""P7 (row 57, MIM): the same pinned momentfm commit and the same pinned model.safetensors under the
transformers version upstream momentfm declares (4.33.3), in an isolated scratch venv
(Python 3.11, torch 2.4.1+cpu, numpy 1.25.2, huggingface-hub 0.24.0; momentfm installed --no-deps
from git commit 38f7310). Local Windows CPU, CUDA_VISIBLE_DEVICES=-1, HF_HUB_OFFLINE=1.
Compares with P6 (transformers 5.16.1, the notebook's pin). Not a Colab run.

Usage: python run_probes_t433.py <snapshot_dir> <results_json_to_update>
"""
import json
import sys
from pathlib import Path

import numpy as np
import torch
import transformers
from momentfm import MOMENTPipeline

snap, out = sys.argv[1], Path(sys.argv[2])
torch.set_num_threads(4)
pipe = MOMENTPipeline.from_pretrained(snap, model_kwargs={"task_name": "reconstruction"}, local_files_only=True)
pipe.init()
pipe.eval()
res = {"transformers": transformers.__version__, "torch": torch.__version__, "numpy": np.__version__}

t = np.arange(512, dtype=np.float32)
cases = {"sine_period_32": np.sin(2 * np.pi * t / 32), "sine_period_96_plus_trend": 28 + 2.5 * np.sin(2 * np.pi * t / 96) + 0.0015 * t}
ones = torch.ones(1, 512)
for name, x in cases.items():
    with torch.no_grad():
        rec = pipe(x_enc=torch.from_numpy(x.astype(np.float32))[None, None, :], input_mask=ones, mask=ones).reconstruction.numpy().ravel()
    res[f"{name}/mask_all_visible"] = {"pearson": float(np.corrcoef(rec, x)[0, 1]), "mae": float(np.abs(rec - x).mean()), "predict_mean_mae": float(np.abs(x - x.mean()).mean())}

# The tutorial sample: 256 steps left-padded to 512, channels [temperature, vibration], final patch hidden.
n = 256
step = np.arange(n, dtype=float)
chans = {}
for channel, base, amplitude, period, phase, trend in (("vibration", 1.5, 0.35, 32.0, 0.0, 0.0008), ("temperature", 28.0, 2.5, 96.0, 9.0, 0.0015)):
    chans[channel] = base + trend * step + amplitude * np.sin(2.0 * np.pi * (step + phase) / period) + 0.08 * np.cos(2.0 * np.pi * step / 16.0)
x = np.zeros((1, 2, 512), dtype=np.float32)
x[0, 0, 256:] = np.round(chans["temperature"], 6)
x[0, 1, 256:] = np.round(chans["vibration"], 6)
input_mask = torch.zeros(1, 512)
input_mask[0, 256:] = 1
for label, s0 in (("trailing_patch_504", 504), ("interior_patch_384", 384)):
    mask = torch.ones(1, 512)
    mask[0, s0:s0 + 8] = 0
    with torch.no_grad():
        rec = pipe(x_enc=torch.from_numpy(x), input_mask=input_mask, mask=mask).reconstruction.numpy()
    hidden = rec[0, :, s0:s0 + 8] - x[0, :, s0:s0 + 8]
    vis = slice(256, s0)
    res[f"sample/{label}"] = {
        "masked_mae_both_channels": float(np.abs(hidden).mean()),
        "masked_mae_temperature": float(np.abs(hidden[0]).mean()),
        "masked_mae_vibration": float(np.abs(hidden[1]).mean()),
        "pearson_visible_temperature": float(np.corrcoef(rec[0, 0, vis], x[0, 0, vis])[0, 1]),
        "pearson_visible_vibration": float(np.corrcoef(rec[0, 1, vis], x[0, 1, vis])[0, 1]),
    }
d = json.loads(out.read_text(encoding="utf-8"))
d["probes"]["P7_same_weights_under_transformers_4_33_3"] = res
out.write_text(json.dumps(d, indent=2, default=str), encoding="utf-8")
print(json.dumps(res, indent=1))
