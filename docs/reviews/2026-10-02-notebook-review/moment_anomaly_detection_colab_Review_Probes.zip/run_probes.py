"""Review probes for tutorials/moment_anomaly_detection_colab.ipynb (row 54, prefix MAD).

Direct execution, local Windows CPU only (CUDA_VISIBLE_DEVICES=-1), venv dimer-moment whose versions
equal the notebook PINS. NOT a Colab run. The install cell runs with the notebook's own
DIMER_NOTEBOOK_CI_PREINSTALLED=1 (nothing installed). The 3-file snapshot is pre-staged by copying the
pinned files into the scratch working directory (so stage_missing_files fetches nothing).

Usage: python run_probes.py <repo_worktree> <workdir> <prestaged_weights_dir>
Writes <workdir>/results.json.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
PRESTAGED = Path(sys.argv[3]).resolve()
NB = REPO / "tutorials" / "moment_anomaly_detection_colab.ipynb"
RESULTS: dict = {"environment": {}, "probes": {}}
WORK.mkdir(parents=True, exist_ok=True)


def record(name, value):
    RESULTS["probes"][name] = value
    (WORK / "results.json").write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


def git(*args):
    return subprocess.run(["git", "-C", str(REPO), *args], capture_output=True, text=True).stdout.strip()


# ---------------- P1 static ----------------
nb = json.loads(NB.read_text(encoding="utf-8"))
code_cells = [i for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
compile_errors = []
for i in code_cells:
    try:
        compile("".join(nb["cells"][i]["source"]), f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append((i, str(exc)))
persisted = [i for i in code_cells if nb["cells"][i].get("outputs") or nb["cells"][i].get("execution_count")]
p1 = {
    "nbformat": f"{nb['nbformat']}.{nb['nbformat_minor']}",
    "cells": len(nb["cells"]),
    "code_cells": len(code_cells),
    "compile_errors": compile_errors,
    "persisted_outputs": persisted,
    "head": git("rev-parse", "HEAD"),
    "blob": git("rev-parse", "HEAD:tutorials/moment_anomaly_detection_colab.ipynb"),
    "recorded_run_blob": "3c11d4ae372196ab6b7a149410bbc24519bb54c0",
    "metadata_dimer": nb["metadata"].get("dimer"),
}
p1["blob_equals_recorded_run"] = p1["blob"] == p1["recorded_run_blob"]
for label, cmd in (
    ("build_check", [sys.executable, "tools/build_notebook.py", "--check"]),
    ("validate_release_assets", [sys.executable, "tools/validate_release_assets.py"]),
):
    proc = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, timeout=300)
    p1[label] = {"exit": proc.returncode, "tail": (proc.stdout + proc.stderr)[-600:]}
record("P1_static", p1)

# ---------------- execution harness ----------------
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ.pop("DIMER_BYOD_PATH", None)
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / "weights" / "moment-1-base"
wdir.mkdir(parents=True, exist_ok=True)
for name in ("README.md", "config.json", "model.safetensors"):
    if not (wdir / name).exists():
        shutil.copy2(PRESTAGED / name, wdir / name)

import torch  # noqa: E402

torch.set_num_threads(4)
RESULTS["environment"] = {
    "python": sys.version.split()[0],
    "torch": torch.__version__,
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "cuda_available": torch.cuda.is_available(),
    "threads": torch.get_num_threads(),
    "workdir": str(WORK),
    "note": "local Windows CPU; not Colab; install skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1; snapshot pre-staged",
}

NS: dict = {"__name__": "__main__"}


def src(i):
    return "".join(nb["cells"][i]["source"])


def run_cell(i, source=None, ns=NS):
    buf = io.StringIO()
    t0 = time.time()
    status, err = "ok", None
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(source if source is not None else src(i), f"cell{i}", "exec"), ns)
        except BaseException as exc:  # noqa: BLE001
            status, err = "error", f"{type(exc).__name__}: {exc}"[:1500]
    return {"cell": i, "status": status, "error": err, "seconds": round(time.time() - t0, 2), "stdout": buf.getvalue()[-3000:]}


# ---------------- P2 default Run all ----------------
p2 = {"cells": []}
t0 = time.time()
for i in code_cells:
    r = run_cell(i)
    p2["cells"].append(r)
    if r["status"] != "ok":
        break
p2["wall_s"] = round(time.time() - t0, 1)
p2["ok"] = sum(r["status"] == "ok" for r in p2["cells"])
p2["outputs"] = sorted(os.listdir("outputs")) if Path("outputs").exists() else []
scores = NS.get("scores")
if scores is not None:
    per_channel = {}
    for ch, g in scores[scores["scored"]].groupby("channel"):
        per_channel[ch] = {"mean": round(float(g.anomaly_score.mean()), 4), "max": round(float(g.anomaly_score.max()), 4)}
    p2["per_channel_scores"] = per_channel
    pooled = scores[scores["scored"]].copy()
    pooled["pooled_rank"] = pooled["anomaly_score"].rank(ascending=False, method="first").astype(int)
    labels = NS["labels"]
    inj = set(labels.loc[labels.is_injected_anomaly, "timestamp"])
    vib = pooled[(pooled.channel == "vibration") & (pooled.timestamp.isin(inj))]
    p2["injected_pooled_ranks_across_channels"] = sorted(vib["pooled_rank"].tolist())
    p2["clean_temperature_points_above_lowest_spike"] = int(
        ((pooled.channel == "temperature") & (pooled.anomaly_score > vib.anomaly_score.min())).sum()
    )
    p2["recall"] = NS["recall"]["value"]
    p2["injected_ranks"] = [r["rank"] for r in NS["recall"]["injected_ranks"]]
    p2["section3_device_print"] = [c["stdout"] for c in p2["cells"] if c["cell"] == 25]
    p2["pipe_identity_device"] = NS["pipe"].identity.device
    p2["pipe_has_device_attr"] = hasattr(NS["pipe"], "device")
    p2["pipe_has_source_attr"] = hasattr(NS["pipe"], "source")
record("P2_default", p2)

# ---------------- P3 active learning ----------------
p3 = {}
if scores is not None:
    base_order = NS["ranked"][["timestamp"]].head(20)["timestamp"].tolist()
    # The interpretation section's suggested experiment: loss="mse", rerun Sections 6 and 7.
    r6 = run_cell(31, src(31).replace('loss="mae"', 'loss="mse"'))
    r7 = run_cell(33)
    mse_order = NS["ranked"][["timestamp"]].head(20)["timestamp"].tolist()
    p3["mse"] = {
        "cells": [r6["status"], r7["status"]],
        "recall": NS["recall"]["value"],
        "injected_ranks": [r["rank"] for r in NS["recall"]["injected_ranks"]],
        "top20_order_identical_to_mae": mse_order == base_order,
        "report_score_semantics": NS["report"].get("score_semantics"),
    }
    # channel aggregation variants (API allows them; not suggested by the notebook)
    for agg in ("mean", "max"):
        r = run_cell(31, src(31).replace('channel_aggregation="none"', f'channel_aggregation="{agg}"'))
        sc = NS.get("scores")
        entry = {"status": r["status"], "error": r["error"]}
        if r["status"] == "ok":
            entry["channels_in_scores"] = sorted(set(sc["channel"]))
            r7 = run_cell(33)
            entry["section7_status"] = r7["status"]
            entry["section7_error"] = r7["error"]
            if r7["status"] == "ok" and NS.get("recall"):
                entry["recall"] = NS["recall"]["value"]
                entry["injected_ranks"] = [x["rank"] for x in NS["recall"]["injected_ranks"]]
        p3[f"aggregation_{agg}"] = entry
    # restore default state
    run_cell(31)
    run_cell(33)
record("P3_active", p3)

# ---------------- P4 naive baselines on the sample (no model) ----------------
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

samples = NS["build_samples"]()
an = samples["moment_anomaly.csv"]
lab = samples["moment_anomaly_labels.csv"]
inj_idx = set(lab.index[lab.is_injected_anomaly])
p4 = {}
for ch in ("vibration",):
    v = an[an.channel == ch]["value"].to_numpy()
    cands = {
        "abs_first_difference": np.abs(np.diff(v, prepend=v[0])),
        "abs_dev_rolling_median_5": np.abs(v - pd.Series(v).rolling(5, center=True, min_periods=1).median().to_numpy()),
        "abs_zscore": np.abs((v - v.mean()) / v.std()),
    }
    for name, s in cands.items():
        top = set(np.argsort(-s, kind="mergesort")[:3])
        p4[f"{ch}:{name}"] = {"top3_recall": len(top & inj_idx) / 3, "top3_idx": sorted(int(x) for x in top)}
record("P4_naive_baselines", p4)

# ---------------- P5 BYOD (DIMER_BYOD_PATH and upload shim) ----------------
p5 = {}
byod_dir = WORK / "byod"
byod_dir.mkdir(exist_ok=True)


def run_from_sample(tag, env_path=None, use_byod_upload=None):
    if env_path:
        os.environ["DIMER_BYOD_PATH"] = str(env_path)
    else:
        os.environ.pop("DIMER_BYOD_PATH", None)
    cells = []
    for i in [c for c in code_cells if c >= 27]:
        source = src(i)
        if i == 27 and use_byod_upload is not None:
            source = source.replace("USE_BYOD = False", "USE_BYOD = True")
            fake = type(sys)("google.colab")
            fake.files = type("F", (), {"upload": staticmethod(lambda: use_byod_upload)})
            sys.modules["google"] = type(sys)("google")
            sys.modules["google.colab"] = fake
        r = run_cell(i, source)
        cells.append(r)
        if r["status"] != "ok":
            break
    os.environ.pop("DIMER_BYOD_PATH", None)
    return cells


# (a) two series, channels not named vibration; A long (600 steps -> truncated), B short with a gap
ts_a = pd.date_range("2026-02-01", periods=600, freq="h")
ts_b = pd.date_range("2026-03-01", periods=120, freq="h")
rows = []
rng = np.random.default_rng(0)
for sid, ts in (("A", ts_a), ("B", ts_b)):
    for ch, base in (("flow", 10.0), ("pressure", 3.0)):
        vals = base + np.sin(np.arange(len(ts)) / 6.0) + 0.05 * rng.standard_normal(len(ts))
        if sid == "B" and ch == "pressure":
            vals[50:58] = np.nan
        if sid == "A" and ch == "flow":
            vals[550] += 6.0
        rows += [(sid, t.strftime("%Y-%m-%dT%H:%M:%S"), ch, v) for t, v in zip(ts, vals)]
good = pd.DataFrame(rows, columns=["series_id", "timestamp", "channel", "value"])
good_path = byod_dir / "two_series.csv"
good.to_csv(good_path, index=False)
cells = run_from_sample("two_series", env_path=good_path)
entry = {"cells": [(c["cell"], c["status"], c["error"]) for c in cells]}
if all(c["status"] == "ok" for c in cells):
    entry["score_channel"] = NS["score_channel"]
    entry["report_verdict"] = NS["report"]["verdict"]
    entry["n_windows"] = NS["windows"].n_windows
    entry["truncated"] = list(map(bool, NS["windows"].truncated))
    entry["padded"] = list(map(bool, NS["windows"].padded))
    entry["scored_fraction"] = NS["result"].scored_point_fraction
    ordered = NS["ranked"].sort_values("timestamp")
    entry["plot_series_interleaved"] = ordered["series_id"].tolist()[:0] or sorted(set(ordered["series_id"]))
    entry["plot_points"] = len(ordered)
    entry["top5"] = NS["ranked"][["series_id", "timestamp", "anomaly_score"]].head(5).astype(str).to_dict("records")
    entry["channels_ranked_in_section7"] = sorted(set(NS["ranked"]["series_id"].astype(str) + ":" + NS["score_channel"]))
    entry["outputs"] = sorted(os.listdir("outputs"))
    entry["result_json_sample_kind"] = json.loads(Path("outputs/moment_anomaly_detection_result.json").read_text())["sample"]["kind"]
    # Is the A:flow spike (index 550) the top-ranked point?
    entry["section7_stdout"] = [c["stdout"][-1200:] for c in cells if c["cell"] == 33]
p5["two_series_env_path"] = entry

# (b) invalid inputs via DIMER_BYOD_PATH
invalid = {
    "duplicate_header": "series_id,timestamp,channel,value,Value\nA,2026-01-01T00:00:00,x,1,2\n",
    "missing_value_column": "series_id,timestamp,channel\nA,2026-01-01T00:00:00,x\n",
    "bad_timestamp": "series_id,timestamp,channel,value\nA,not-a-time,x,1\nA,2026-01-01T01:00:00,x,2\n",
    "non_numeric_value": "series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,x,abc\nA,2026-01-01T01:00:00,x,2\n",
    "duplicate_rows": "series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,x,1\nA,2026-01-01T00:00:00,x,2\n",
    "latin1_bytes": None,
}
for name, text in invalid.items():
    path = byod_dir / f"{name}.csv"
    if text is None:
        path.write_bytes("series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,caf\xe9,1\n".encode("latin-1"))
    else:
        path.write_text(text, encoding="utf-8")
    cells = run_from_sample(name, env_path=path)
    last = cells[-1]
    p5[f"invalid:{name}"] = {"failed_cell": last["cell"] if last["status"] != "ok" else None, "error": last["error"], "cells_run": len(cells)}

# (c) single-channel BYOD: the Section 5 empty-channel probe empties the only channel
single = good[(good.channel == "flow") & (good.series_id == "A")]
single_path = byod_dir / "single_channel.csv"
single.to_csv(single_path, index=False)
cells = run_from_sample("single", env_path=single_path)
entry = {"cells": [(c["cell"], c["status"], c["error"]) for c in cells]}
if all(c["status"] == "ok" for c in cells):
    entry["manifest_findings"] = NS["input_manifest"]["findings"]
p5["single_channel"] = entry

# (d) upload shim: cancelled dialog ({}), two files
for tag, uploaded in (("upload_cancelled", {}), ("upload_two_files", {"a.csv": b"x", "b.csv": b"y"})):
    cells = run_from_sample(tag, use_byod_upload=uploaded)
    p5[tag] = {"cell": cells[-1]["cell"], "status": cells[-1]["status"], "error": cells[-1]["error"]}
record("P5_byod", p5)
print("done")
