"""Review probes for tutorials/moment_embeddings_colab.ipynb (row 56, prefix MEM).

Direct execution, local Windows CPU only (CUDA_VISIBLE_DEVICES=-1, 4 torch threads), venv dimer-moment whose
versions equal the notebook PINS. NOT a Colab run. The install cell runs with the notebook's own
DIMER_NOTEBOOK_CI_PREINSTALLED=1 (nothing installed). The 3-file snapshot is pre-staged by copying the pinned
files into the scratch working directory (stage_missing_files then fetches nothing); HF_HUB_OFFLINE=1.
Scale: the default sample is tiny (1 series, 2 channels, 256 steps); BYOD probes use small synthetic CSVs.

Usage: python run_probes.py <repo_worktree> <workdir> <prestaged_weights_dir> [<hosted_outputs_dir>]
Writes <workdir>/results.json (written after every probe).
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
PRESTAGED = Path(sys.argv[3]).resolve()
HOSTED = Path(sys.argv[4]).resolve() if len(sys.argv) > 4 else None
NB = REPO / "tutorials" / "moment_embeddings_colab.ipynb"
RESULTS: dict = {"environment": {}, "probes": {}}
WORK.mkdir(parents=True, exist_ok=True)


def record(name, value):
    RESULTS["probes"][name] = value
    (WORK / "results.json").write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


def git(*args):
    return subprocess.run(["git", "-C", str(REPO), *args], capture_output=True, text=True).stdout.strip()


# ---------------- P1 static ----------------
nb = json.loads(NB.read_text(encoding="utf-8"))
code_cells = [i for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
compile_errors = []
for i in code_cells:
    try:
        compile("".join(nb["cells"][i]["source"]), f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append((i, str(exc)))
persisted = [i for i in code_cells if nb["cells"][i].get("outputs") or nb["cells"][i].get("execution_count")]
p1 = {
    "nbformat": f"{nb['nbformat']}.{nb['nbformat_minor']}",
    "cells": len(nb["cells"]),
    "code_cells": len(code_cells),
    "compile_errors": compile_errors,
    "persisted_outputs": persisted,
    "head": git("rev-parse", "HEAD"),
    "blob": git("rev-parse", "HEAD:tutorials/moment_embeddings_colab.ipynb"),
    "recorded_run_blob": "b294013f0fa7563c9eaea18d34f120ff4c19f99e",
    "metadata_dimer": nb["metadata"].get("dimer"),
    "carried_module_chars": sum(len("".join(nb["cells"][i]["source"])) for i in range(5, 24, 2)),
}
p1["blob_equals_recorded_run"] = p1["blob"] == p1["recorded_run_blob"]
for label, cmd in (
    ("build_check", [sys.executable, "tools/build_notebook.py", "--check"]),
    ("validate_release_assets", [sys.executable, "tools/validate_release_assets.py"]),
):
    proc = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, timeout=300)
    p1[label] = {"exit": proc.returncode, "tail": (proc.stdout + proc.stderr)[-600:]}
record("P1_static", p1)

# ---------------- execution harness ----------------
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ.pop("DIMER_BYOD_PATH", None)
os.chdir(WORK)
wdir = WORK / "weights" / "moment-1-base"
wdir.mkdir(parents=True, exist_ok=True)
for name in ("README.md", "config.json", "model.safetensors"):
    if not (wdir / name).exists():
        shutil.copy2(PRESTAGED / name, wdir / name)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402

torch.set_num_threads(4)
RESULTS["environment"] = {
    "python": sys.version.split()[0],
    "torch": torch.__version__,
    "numpy": np.__version__,
    "pandas": pd.__version__,
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "cuda_available": torch.cuda.is_available(),
    "threads": torch.get_num_threads(),
    "workdir": str(WORK),
    "note": "local Windows CPU; not Colab; install skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1; snapshot pre-staged; HF_HUB_OFFLINE=1",
}

NS: dict = {"__name__": "__main__"}


def src(i):
    return "".join(nb["cells"][i]["source"])


def run_cell(i, source=None, ns=NS):
    buf = io.StringIO()
    t0 = time.time()
    status, err = "ok", None
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(source if source is not None else src(i), f"cell{i}", "exec"), ns)
        except BaseException as exc:  # noqa: BLE001
            status, err = "error", f"{type(exc).__name__}: {exc}"[:1500]
    return {"cell": i, "status": status, "error": err, "seconds": round(time.time() - t0, 2), "stdout": buf.getvalue()[-3000:]}


def cos(a, b):
    a, b = np.asarray(a, float).ravel(), np.asarray(b, float).ravel()
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b)))


# ---------------- P2 default Run all ----------------
p2 = {"cells": []}
t0 = time.time()
for i in code_cells:
    r = run_cell(i)
    p2["cells"].append(r)
    if r["status"] != "ok":
        break
p2["wall_s"] = round(time.time() - t0, 1)
p2["ok"] = sum(r["status"] == "ok" for r in p2["cells"])
p2["outputs"] = sorted(os.listdir("outputs")) if Path("outputs").exists() else []
res = NS.get("result")
if res is not None:
    clean_vec = res.embeddings.copy()
    p2["embedding_shape"] = list(res.embeddings.shape)
    p2["l2_norm_window0"] = float(np.linalg.norm(res.embeddings[0]))
    p2["missingness_visible_to_model_printed"] = res.missingness_visible_to_model
    p2["input_manifest_schema_values"] = NS["input_manifest"]["schema"]["values"]
    p2["report_verdict"] = NS["report"]["verdict"]
    p2["report_needs"] = NS["report"].get("needs")
    p2["section3_stdout"] = [c["stdout"] for c in p2["cells"] if c["cell"] == 25]
    p2["pipe_identity_device"] = NS["pipe"].identity.device
    p2["pipe_has_device_attr"] = hasattr(NS["pipe"], "device")
    p2["pipe_has_source_attr"] = hasattr(NS["pipe"], "source")
    p2["valid_positions"] = NS["input_manifest"]["inputs"][0]["valid_positions"]
    p2["padded"] = list(NS["windows"].padded)
    if HOSTED is not None and (HOSTED / "moment_embeddings.csv").exists():
        hosted = pd.read_csv(HOSTED / "moment_embeddings.csv")
        hv = hosted[[c for c in hosted.columns if c.startswith("embedding_")]].to_numpy()
        p2["hosted_max_abs_diff"] = float(np.abs(hv - res.embeddings).max())
        p2["hosted_cosine"] = cos(hv, res.embeddings)
record("P2_default", p2)

# ---------------- P3 missingness semantics (the objective the default sample never exercises) ----------------
p3 = {}
if res is not None:
    cfg = NS["MomentConfig"](task="embedding")
    frame = NS["frame"]

    def embed_frame(f):
        rep, norm = NS["validate_long_frame"](f, cfg)
        w = NS["to_windows"](norm, cfg, report=rep, frame=norm)
        out = NS["embed"](w, NS["pipe"], warmup=False)
        return out, w

    # 25% of vibration points missing (every 4th step), NaN in the CSV
    miss = frame.copy()
    vib_idx = miss.index[miss["channel"] == "vibration"]
    drop = vib_idx[::4]
    miss.loc[drop, "value"] = np.nan
    r_miss, w_miss = embed_frame(miss)
    # Same positions written as the literal prefill value (0.0) -- observed data, no NaN
    lit = frame.copy()
    lit.loc[drop, "value"] = float(cfg.prefill_value)
    r_lit, w_lit = embed_frame(lit)
    # Linear interpolation of the same gaps (what a learner might do instead)
    interp = miss.copy()
    interp.loc[interp.channel == "vibration", "value"] = interp.loc[interp.channel == "vibration", "value"].interpolate()
    r_int, _ = embed_frame(interp)
    p3 = {
        "masked_points": int(len(drop)),
        "masked_point_fraction": w_miss.masked_point_fraction,
        "missingness_visible_to_model_flag": r_miss.missingness_visible_to_model,
        "nan_vs_literal_prefill_max_abs_diff": float(np.abs(r_miss.embeddings - r_lit.embeddings).max()),
        "nan_vs_literal_prefill_identical": bool(np.array_equal(r_miss.embeddings, r_lit.embeddings)),
        "cosine_clean_vs_missing": cos(clean_vec, r_miss.embeddings),
        "cosine_clean_vs_interpolated": cos(clean_vec, r_int.embeddings),
        "l2_clean_minus_missing": float(np.linalg.norm(clean_vec - r_miss.embeddings)),
        "l2_clean_minus_interpolated": float(np.linalg.norm(clean_vec - r_int.embeddings)),
    }
    # Affine rescale per channel (RevIN normalizes per window/channel) -- a simple, teachable invariance
    scaled = frame.copy()
    scaled["value"] = scaled["value"] * 10.0 + 5.0
    r_sc, _ = embed_frame(scaled)
    p3["cosine_clean_vs_affine_rescaled"] = cos(clean_vec, r_sc.embeddings)
    p3["max_abs_diff_clean_vs_affine_rescaled"] = float(np.abs(clean_vec - r_sc.embeddings).max())
    # Channel-order / single-channel: what does a 2-channel vector represent?
    vib_only = frame[frame.channel == "vibration"].copy()
    tmp_only = frame[frame.channel == "temperature"].copy()
    r_v, _ = embed_frame(vib_only)
    r_t, _ = embed_frame(tmp_only)
    p3["cosine_clean_vs_vibration_only"] = cos(clean_vec, r_v.embeddings)
    p3["cosine_clean_vs_temperature_only"] = cos(clean_vec, r_t.embeddings)
    p3["cosine_vibration_only_vs_temperature_only"] = cos(r_v.embeddings, r_t.embeddings)
record("P3_missingness_and_semantics", p3)

# ---------------- P4 BYOD (the notebook's suggested next experiment) + invalid inputs ----------------
p4 = {}


def write_csv(name, frame=None, text=None, encoding="utf-8"):
    path = WORK / "byod" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if text is not None:
        path.write_bytes(text.encode(encoding))
    else:
        frame.to_csv(path, index=False, date_format="%Y-%m-%dT%H:%M:%S")
    return path


rng = np.random.default_rng(0)
rows = []
tA = pd.date_range("2026-03-01", periods=600, freq="h")
tB = pd.date_range("2026-03-01", periods=120, freq="h")
for sid, ts in (("A", tA), ("B", tB)):
    for ch, base in (("flow", 10.0), ("pressure", 3.0)):
        v = base + np.sin(np.arange(len(ts)) / 12.0) + rng.normal(0, 0.1, len(ts))
        rows += [(sid, t, ch, float(x)) for t, x in zip(ts, v)]
byod = pd.DataFrame(rows, columns=["series_id", "timestamp", "channel", "value"])
byod = byod[~((byod.series_id == "B") & (byod.timestamp.isin(tB[40:48])))]  # 8-step gap in B
good = write_csv("two_series.csv", byod)
os.environ["DIMER_BYOD_PATH"] = str(good)
cells_after = [i for i in code_cells if i >= 27]
byod_run = [run_cell(i) for i in cells_after]
p4["two_series"] = {
    "cells": [(r["cell"], r["status"], r["error"]) for r in byod_run],
    "embedding_shape": list(NS["result"].embeddings.shape) if NS.get("result") is not None else None,
    "window_ids": list(NS["result"].window_ids) if NS.get("result") is not None else None,
    "padded": list(NS["windows"].padded),
    "truncated": list(NS["windows"].truncated),
    "irregular_series": NS["input_manifest"].get("irregular_series"),
    "masked_point_fraction": NS["windows"].masked_point_fraction,
    "report_verdict": NS["report"]["verdict"],
    "sample_kind_in_result": json.loads(Path("outputs/moment_embeddings_result.json").read_text(encoding="utf-8"))["sample"],
    "csv_rows": len(pd.read_csv("outputs/moment_embeddings.csv")),
    "l2_print_covers_only_window0": "embeddings[0]" in src(31),
    "cell29_stdout_tail": byod_run[1]["stdout"][-900:] if len(byod_run) > 1 else None,
}
if NS.get("result") is not None and NS["result"].embeddings.shape[0] == 2:
    p4["two_series"]["cosine_A_vs_B"] = cos(NS["result"].embeddings[0], NS["result"].embeddings[1])
record("P4_byod", p4)

invalid = {
    "duplicate_header": "series_id,timestamp,channel,value,value\nA,2026-01-01T00:00:00,x,1.0,2.0\n",
    "missing_value_column": "series_id,timestamp,channel\nA,2026-01-01T00:00:00,x\n",
    "latin1_bytes": None,
    "unparseable_timestamp": "series_id,timestamp,channel,value\nA,not-a-time,x,1.0\nA,2026-01-01T01:00:00,x,2.0\n",
    "non_numeric_value": "series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,x,abc\nA,2026-01-01T01:00:00,x,2.0\n",
    "duplicate_key": "series_id,timestamp,channel,value\nA,2026-01-01T00:00:00,x,1.0\nA,2026-01-01T00:00:00,x,2.0\n",
}
p4["invalid"] = {}
for name, text in invalid.items():
    if name == "latin1_bytes":
        path = write_csv(name + ".csv", text="series_id,timestamp,channel,value\nAé,2026-01-01T00:00:00,x,1.0\n", encoding="latin-1")
    else:
        path = write_csv(name + ".csv", text=text)
    os.environ["DIMER_BYOD_PATH"] = str(path)
    r27 = run_cell(27)
    entry = {"cell27": r27["status"], "error27": r27["error"]}
    if r27["status"] == "ok":
        r29 = run_cell(29)
        entry.update({"cell29": r29["status"], "error29": r29["error"]})
    p4["invalid"][name] = entry
record("P4_byod", p4)

# Jupyter path: USE_BYOD=True without DIMER_BYOD_PATH and without google.colab
os.environ.pop("DIMER_BYOD_PATH", None)
r = run_cell(27, src(27).replace("USE_BYOD = False", "USE_BYOD = True"))
p4["use_byod_true_without_colab"] = {"status": r["status"], "error": r["error"]}
# Colab upload shim: zero files (cancelled dialog)
import types  # noqa: E402

shim = types.ModuleType("google.colab")
shim.files = types.SimpleNamespace(upload=lambda: {})
sys.modules["google"] = types.ModuleType("google")
sys.modules["google.colab"] = shim
r = run_cell(27, src(27).replace("USE_BYOD = False", "USE_BYOD = True"))
p4["upload_cancelled_shim"] = {"status": r["status"], "error": r["error"]}
record("P4_byod", p4)
print(json.dumps(RESULTS["probes"].get("P2_default", {}).get("wall_s")), "done")
